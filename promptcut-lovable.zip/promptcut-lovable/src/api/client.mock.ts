// Mock API client for Lovable demo
// Replace the real client.ts with this for demo purposes

import type { Project, Media, Timeline, Job, Export, EditPlan } from '../types';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock data
const mockProject: Project = {
  id: 'demo-project-1',
  title: 'Demo Project',
  fps: 30,
  resolution: '1920x1080',
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

const mockMedia: Media[] = [
  {
    id: 'media-1',
    project_id: 'demo-project-1',
    filename: 'sample-video-1.mp4',
    uri_original: 'https://example.com/video1.mp4',
    uri_proxy: 'https://example.com/proxy1.mp4',
    uri_thumbnail: 'https://via.placeholder.com/640x360/8b5cf6/ffffff?text=Video+1',
    duration: 45.5,
    fps: 30,
    width: 1920,
    height: 1080,
    media_type: 'video',
    created_at: new Date().toISOString(),
  },
  {
    id: 'media-2',
    project_id: 'demo-project-1',
    filename: 'sample-video-2.mp4',
    uri_original: 'https://example.com/video2.mp4',
    uri_proxy: 'https://example.com/proxy2.mp4',
    uri_thumbnail: 'https://via.placeholder.com/640x360/06b6d4/ffffff?text=Video+2',
    duration: 32.8,
    fps: 30,
    width: 1920,
    height: 1080,
    media_type: 'video',
    created_at: new Date().toISOString(),
  },
  {
    id: 'media-3',
    project_id: 'demo-project-1',
    filename: 'background-music.mp3',
    uri_original: 'https://example.com/music.mp3',
    duration: 120,
    media_type: 'audio',
    created_at: new Date().toISOString(),
  },
];

const mockTimeline: Timeline = {
  id: 'timeline-1',
  project_id: 'demo-project-1',
  version: 1,
  state_json: {
    tracks: [
      {
        id: 'track-video-1',
        type: 'video',
        clips: [
          {
            id: 'clip-1',
            media_id: 'media-1',
            start_time: 0,
            duration: 10,
            trim_start: 0,
            trim_end: 10,
          },
          {
            id: 'clip-2',
            media_id: 'media-2',
            start_time: 10,
            duration: 8,
            trim_start: 0,
            trim_end: 8,
          },
        ],
      },
      {
        id: 'track-audio-1',
        type: 'audio',
        clips: [
          {
            id: 'clip-3',
            media_id: 'media-3',
            start_time: 0,
            duration: 18,
            trim_start: 0,
            trim_end: 18,
            volume: 0.7,
          },
        ],
      },
    ],
    duration: 18,
    fps: 30,
  },
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

// Mock API
export const projectsApi = {
  list: async () => {
    await delay(300);
    return { data: [mockProject] };
  },
  get: async (id: string) => {
    await delay(200);
    return { data: mockProject };
  },
  create: async (data: any) => {
    await delay(500);
    return { data: { ...mockProject, ...data, id: 'new-' + Date.now() } };
  },
  update: async (id: string, data: any) => {
    await delay(300);
    return { data: { ...mockProject, ...data } };
  },
  delete: async (id: string) => {
    await delay(200);
    return { data: { success: true } };
  },
};

export const mediaApi = {
  list: async (projectId: string) => {
    await delay(400);
    return { data: mockMedia };
  },
  get: async (id: string) => {
    await delay(200);
    const media = mockMedia.find(m => m.id === id);
    return { data: media || mockMedia[0] };
  },
  delete: async (id: string) => {
    await delay(300);
    return { data: { success: true } };
  },
};

export const uploadApi = {
  requestUpload: async (data: any) => {
    await delay(500);
    return {
      data: {
        upload_url: 'https://example.com/upload',
        media_id: 'new-media-' + Date.now(),
        file_key: 'uploads/' + data.filename,
        job_id: 'job-' + Date.now(),
      },
    };
  },
  uploadFile: async (uploadUrl: string, file: File) => {
    await delay(2000);
    return { data: { success: true } };
  },
};

export const timelineApi = {
  get: async (projectId: string) => {
    await delay(300);
    return { data: mockTimeline };
  },
  getById: async (id: string) => {
    await delay(200);
    return { data: mockTimeline };
  },
  applyActions: async (data: any) => {
    await delay(1000);
    // Simulate adding clips based on actions
    const newTimeline = { ...mockTimeline };
    return { data: { success: true, timeline: newTimeline } };
  },
};

export const aiApi = {
  generatePlan: async (data: any) => {
    await delay(800);
    return {
      data: {
        job_id: 'ai-job-' + Date.now(),
        status: 'pending',
      },
    };
  },
  generatePlanSync: async (data: any) => {
    await delay(2000);
    const mockPlan: EditPlan = {
      duration: 30,
      style: 'fast-paced',
      structure: [
        { section: 'intro', goal: 'hook viewer', duration: 5 },
        { section: 'main', goal: 'showcase content', duration: 20 },
        { section: 'outro', goal: 'call to action', duration: 5 },
      ],
      actions: [
        { type: 'cut', asset: 'media-1', in: 0, out: 5 },
        { type: 'transition', style: 'crossfade', duration: 1 },
        { type: 'cut', asset: 'media-2', in: 0, out: 8 },
        { type: 'overlayText', text: 'Demo Video', time: 2, duration: 3 },
      ],
    };
    return { data: { plan: mockPlan, success: true } };
  },
};

export const exportApi = {
  start: async (data: any) => {
    await delay(600);
    return {
      data: {
        export_id: 'export-' + Date.now(),
        job_id: 'job-' + Date.now(),
        status: 'pending',
      },
    };
  },
  get: async (id: string) => {
    await delay(300);
    const mockExport: Export = {
      id,
      project_id: 'demo-project-1',
      filename: 'export_demo.mp4',
      format: 'mp4',
      resolution: '1920x1080',
      status: 'completed',
      download_url: 'https://example.com/download/demo.mp4',
      job_progress: 100,
      created_at: new Date().toISOString(),
    };
    return { data: mockExport };
  },
  list: async (projectId: string) => {
    await delay(300);
    return { data: [] };
  },
};

export const jobsApi = {
  get: async (id: string) => {
    await delay(200);
    const mockJob: Job = {
      id,
      project_id: 'demo-project-1',
      type: 'render',
      status: 'completed',
      progress: 100,
      created_at: new Date().toISOString(),
    };
    return { data: mockJob };
  },
  list: async (params?: any) => {
    await delay(300);
    return { data: [] };
  },
};

export default {};
